#!/bin/sh
set -e
npm install
node server.js
