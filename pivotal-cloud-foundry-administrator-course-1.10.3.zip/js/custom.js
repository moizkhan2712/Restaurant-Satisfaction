$(window).on("scroll touchmove", function () {
    $("#sidebar").toggleClass("top", $(document).scrollTop() > 253);
});

document.querySelectorAll("[data-url-field]").forEach(function (element) {
    var urlField = element.getAttribute("data-url-field");
    var href = element.getAttribute("href");

    element.setAttribute("href", href + "?" + urlField + "=" + window.location)
});

$(function() {
    var copyButton = "<button class=\"pbcopy\" title=\"Copy content\"><svg style=\"width:24px;height:24px\" viewBox=\"0 0 24 24\"><path fill=\"#666666\" d=\"M17,9H7V7H17M17,13H7V11H17M14,17H7V15H14M12,3A1,1 0 0,1 13,4A1,1 0 0,1 12,5A1,1 0 0,1 11,4A1,1 0 0,1 12,3M19,3H14.82C14.4,1.84 13.3,1 12,1C10.7,1 9.6,1.84 9.18,3H5A2,2 0 0,0 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5A2,2 0 0,0 19,3Z\" /></svg></button>";
    var copyTextArea = "<textarea id=\"pbcopy\" style=\"position: absolute; left: -1000em;\"></textarea>";
    $("body").append(copyTextArea);

    var $copyTextArea = $("#pbcopy");

    $("pre").each(function() {
        var $pre = $(this);
        $pre.prepend(copyButton);
        $pre.find(".pbcopy").click(function() {
            $copyTextArea.html($pre.text());
            $copyTextArea.select();
            document.execCommand("copy")
        })
    })
});
